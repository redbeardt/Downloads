:: INSTALLATION INSTRUCTIONS ::

For version A19.2 (b4) of 7 Days To Die.

- If installing to vanilla 7DTD, copy the two folders into your 7DTD directory.

- If installing to a modded 7DTD that already has 0Harmony.dll and DMT.dll in the 7DaysToDie_Data/Managed directory, you can just drop the Redbeardt-ActiveIngredients directory into your Mods directory.