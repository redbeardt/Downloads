:: Active Ingredients v3, by Redbeardt ::

This mod will enable you to click on recipe ingredients to see what recipes can produce it. Ingredients will highlight to let you know that there are available recipes.

From version 3 you can use right-click or mouse4 (thumb button 1) to go "back" through recipes you have viewed. The mod holds a history of ten viewed recipes, and each workstation type has its own history. When you click to go back, the mod will try to find the recipe in the visible recipe list and select it, but failing that, the recipe list will clear out and only the newly viewed recipe.

:: INSTALLATION INSTRUCTIONS ::

For version A19.2 (b4) of 7 Days To Die.

- If installing to vanilla 7DTD, copy the two folders into your 7DTD directory.

- If installing to a modded 7DTD that already has 0Harmony.dll and DMT.dll in the 7DaysToDie_Data/Managed directory, you can just drop the Redbeardt-ActiveIngredients directory into your Mods directory.